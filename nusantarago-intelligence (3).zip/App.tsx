
import React, { useState, useEffect } from 'react';
import LandingPage from './components/LandingPage';
import AuthPage from './components/AuthPage';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import { User, TripPlan, UserInput, ViewState } from './types';
import { generateItinerary } from './services/geminiService';
import { AlertTriangle } from 'lucide-react';

const App: React.FC = () => {
  const [viewState, setViewState] = useState<ViewState>('landing');
  const [user, setUser] = useState<User | null>(null);
  const [tripPlan, setTripPlan] = useState<TripPlan | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);

  // --- Dark Mode Logic ---
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // --- Actions ---

  const handleLogin = (userData: { name: string; email: string }) => {
    // Check if new user (simulated)
    const isNewUser = userData.email.includes('new');
    
    if (isNewUser) {
      setUser({
        name: "Daffa",
        email: userData.email,
        avatar: '', // To be set in Onboarding
        isPremium: false
      });
      setViewState('onboarding');
    } else {
      // SETTING MOCK USER DATA FOR DAFFA
      setUser({ 
          name: "Daffa", 
          email: "daffa@nusantarago.id",
          // Menggunakan foto profil yang lebih realistis (Unsplash)
          avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop',
          phone: '+62 812 3456 7890',
          location: 'Jakarta, Indonesia',
          memberSince: 'Jan 2024',
          level: 'Sultan', // Updated Level
          points: 12450, // Updated Points
          miles: 4800,
          walletBalance: 2500000, // Richer wallet
          badges: ['Early Adopter', 'Bali Expert', 'Sultan Tier'],
          isPremium: true
      });
      setViewState('dashboard');
    }
  };

  const handleOnboardingComplete = (avatar: string, name: string) => {
    if (user) {
      setUser({
        ...user,
        name: name,
        avatar: avatar,
        level: 'Newbie Explorer',
        points: 50, // Welcome bonus
        miles: 0,
        walletBalance: 0,
        memberSince: 'Just now'
      });
      setViewState('dashboard');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setTripPlan(null);
    setViewState('landing');
  };

  const handleGenerateTrip = async (input: UserInput) => {
    setIsLoading(true);
    setError(null);
    try {
      // Small delay to allow UI to show loading state nicely
      const plan = await generateItinerary(input);
      setTripPlan(plan);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Terjadi kesalahan saat menghubungi AI.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetTrip = () => {
    setTripPlan(null);
  };

  // --- Render ---

  return (
    <div className={`font-sans ${isDarkMode ? 'dark' : ''}`}>
      {error && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[60] bg-red-50 border border-red-200 text-red-700 px-6 py-4 rounded-xl shadow-xl flex items-center gap-3 max-w-lg w-full mx-4 animate-in slide-in-from-top-2">
          <AlertTriangle size={24} />
          <div>
            <h4 className="font-bold">Error</h4>
            <p className="text-sm">{error}</p>
          </div>
          <button 
            onClick={() => setError(null)}
            className="ml-auto text-red-400 hover:text-red-600 font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {viewState === 'landing' && (
        <LandingPage onGetStarted={() => setViewState('auth')} />
      )}

      {viewState === 'auth' && (
        <AuthPage onLogin={handleLogin} />
      )}

      {viewState === 'onboarding' && (
        <Onboarding onComplete={handleOnboardingComplete} />
      )}

      {viewState === 'dashboard' && user && (
        <Dashboard 
          user={user} 
          onLogout={handleLogout}
          onGenerateTrip={handleGenerateTrip}
          tripPlan={tripPlan}
          isLoading={isLoading}
          onResetTrip={handleResetTrip}
          isDarkMode={isDarkMode}
          toggleDarkMode={toggleDarkMode}
        />
      )}
    </div>
  );
};

export default App;
