
import React, { useState } from 'react';
import { Search, MapPin, ChevronLeft, ChevronRight, BookOpen } from 'lucide-react';
import { LibraryItem } from '../types';

const MOCK_LIBRARY: LibraryItem[] = [
  { id: '1', name: 'Gedung Sate', city: 'Bandung', province: 'Jawa Barat', category: 'Sejarah', description: 'Ikon kota Bandung dengan arsitektur kolonial yang megah.', image: 'https://images.unsplash.com/photo-1558258385-48fa2c2f6d50?q=80&w=600&auto=format&fit=crop' },
  { id: '2', name: 'Kawah Putih', city: 'Bandung', province: 'Jawa Barat', category: 'Alam', description: 'Danau kawah vulkanik dengan air berwarna turkis yang surealis.', image: 'https://images.unsplash.com/photo-1542858023-e18798e9c600?q=80&w=600&auto=format&fit=crop' },
  { id: '3', name: 'Jalan Braga', city: 'Bandung', province: 'Jawa Barat', category: 'Lifestyle', description: 'Jalan bersejarah dengan kafe-kafe estetik dan nuansa Eropa.', image: 'https://images.unsplash.com/photo-1634057863583-057404456950?q=80&w=600&auto=format&fit=crop' },
  { id: '4', name: 'Tangkuban Perahu', city: 'Bandung', province: 'Jawa Barat', category: 'Alam', description: 'Gunung berapi aktif yang bisa dicapai dengan kendaraan sampai bibir kawah.', image: 'https://images.unsplash.com/photo-1605696229976-58c0353c7a23?q=80&w=600&auto=format&fit=crop' },
];

const TravelerLibrary: React.FC = () => {
  const [selectedProvince, setSelectedProvince] = useState('Jawa Barat');
  const [selectedCity, setSelectedCity] = useState('Bandung');

  return (
    <div className="max-w-7xl mx-auto pb-20 animate-in fade-in slide-in-from-bottom-4">
      <div className="flex items-center gap-3 mb-8">
        <div className="bg-emerald-600 p-3 rounded-2xl text-white shadow-lg shadow-emerald-600/20">
          <BookOpen size={24} />
        </div>
        <div>
          <h2 className="text-3xl font-extrabold text-slate-800 dark:text-white">Traveler Library</h2>
          <p className="text-slate-500 dark:text-slate-400">Pustaka visual destinasi terlengkap se-Nusantara.</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-4 mb-8 bg-white dark:bg-dark-card p-4 rounded-2xl shadow-sm border border-slate-200 dark:border-dark-border">
        <div className="relative flex-1">
          <label className="text-xs font-bold text-slate-400 uppercase ml-1 mb-1 block">Provinsi</label>
          <select 
            value={selectedProvince}
            onChange={(e) => setSelectedProvince(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 font-bold text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option>Jawa Barat</option>
            <option>Bali</option>
            <option>DI Yogyakarta</option>
            <option>Nusa Tenggara Timur</option>
          </select>
        </div>
        <div className="relative flex-1">
          <label className="text-xs font-bold text-slate-400 uppercase ml-1 mb-1 block">Kota / Kabupaten</label>
          <select 
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2 font-bold text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
          >
            <option>Bandung</option>
            <option>Bogor</option>
            <option>Cirebon</option>
            <option>Pangandaran</option>
          </select>
        </div>
        <button className="bg-emerald-600 text-white px-6 rounded-xl font-bold hover:bg-emerald-700 transition-colors self-end py-2 h-[42px]">
          <Search size={20} />
        </button>
      </div>

      {/* Visual Content */}
      <div className="space-y-8">
        <div className="flex items-center justify-between">
           <h3 className="text-2xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
             <MapPin className="text-emerald-500" /> {selectedCity}, {selectedProvince}
           </h3>
           <div className="flex gap-2">
             <button className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-slate-500 dark:text-slate-400 transition-colors">
               <ChevronLeft size={20} />
             </button>
             <button className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-slate-500 dark:text-slate-400 transition-colors">
               <ChevronRight size={20} />
             </button>
           </div>
        </div>

        {/* Horizontal Scroll Container */}
        <div className="flex gap-6 overflow-x-auto pb-8 scrollbar-hide snap-x snap-mandatory">
          {MOCK_LIBRARY.map((item) => (
            <div key={item.id} className="min-w-[300px] md:min-w-[400px] snap-center group relative h-[500px] rounded-3xl overflow-hidden cursor-pointer shadow-lg border border-slate-200 dark:border-dark-border">
              <img 
                src={item.image} 
                alt={item.name} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent flex flex-col justify-end p-8">
                <span className="inline-block px-3 py-1 bg-white/20 backdrop-blur-md text-white text-xs font-bold rounded-lg mb-3 w-fit border border-white/20">
                  {item.category}
                </span>
                <h4 className="text-3xl font-bold text-white mb-2 leading-tight">{item.name}</h4>
                <p className="text-slate-300 text-sm line-clamp-2 mb-4 group-hover:line-clamp-none transition-all">{item.description}</p>
                
                <button className="w-full py-3 bg-white text-slate-900 font-bold rounded-xl opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-300">
                  Lihat Detail
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TravelerLibrary;
