
import React, { useState } from 'react';
import { User, TripPlan, UserInput, DashboardView } from '../types';
import { Home, PlusCircle, Compass, LogOut, Bell, Menu, X, Wallet, Calendar, User as UserIcon, CheckSquare, Cloud, Flame, Gem, DollarSign, Users, Moon, Sun, Bot, MessageSquare, Map, BookOpen, Gift, TrendingUp, Filter, ChevronRight, Wrench, Gamepad2 } from 'lucide-react';
import TripPlanner from './TripPlanner';
import ItineraryView from './ItineraryView';
import UserProfile from './UserProfile';
import TripReady from './TripReady';
import Community from './Community';
import MonetizationHub from './MonetizationHub';
import VisualRouteMap from './VisualRouteMap';
import TravelerLibrary from './TravelerLibrary';
import PanduCommandCenter from './PanduCommandCenter';
import NusantaraLingo from './NusantaraLingo';
import LiveActivityPopup from './LiveActivityPopup';
import AIToolsHub from './AIToolsHub';
import PlayZoneHub from './games/PlayZoneHub';
import { optimizeTripBudget } from '../services/geminiService';

interface DashboardProps {
  user: User;
  onLogout: () => void;
  onGenerateTrip: (input: UserInput) => Promise<void>;
  tripPlan: TripPlan | null;
  isLoading: boolean;
  onResetTrip: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  user, onLogout, onGenerateTrip, tripPlan, isLoading, onResetTrip, isDarkMode, toggleDarkMode
}) => {
  const [activeView, setActiveView] = useState<DashboardView>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Vertical Filters
  const [showRightFilters, setShowRightFilters] = useState(true);
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  
  // Pandu AI State
  const [isPanduOpen, setIsPanduOpen] = useState(false);
  
  // Wallet
  const [walletAmount, setWalletAmount] = useState(user.walletBalance || 0);
  
  // PlayZone Miles State (Local sync for demo)
  const [userMiles, setUserMiles] = useState(user.miles || 0);

  React.useEffect(() => {
    if (tripPlan) {
      setActiveView('trip_detail');
    }
  }, [tripPlan]);
  
  React.useEffect(() => {
    setWalletAmount(user.walletBalance || 0);
  }, [user.walletBalance]);

  const handleGenerate = async (input: UserInput) => {
    await onGenerateTrip(input);
  };

  const handleBackToPlanner = () => {
    onResetTrip();
    setActiveView('planner');
  };

  const [optimizedPlan, setOptimizedPlan] = useState<TripPlan | null>(null);
  const displayPlan = optimizedPlan || tripPlan;
  
  React.useEffect(() => {
    setOptimizedPlan(null);
  }, [tripPlan]);

  const handleOptimizeBudget = async (currentPlan: TripPlan) => {
    if (!walletAmount) return;
    try {
      const newPlan = await optimizeTripBudget(currentPlan, walletAmount);
      setOptimizedPlan(newPlan);
    } catch (error) {
      console.error("Optimization failed", error);
      throw error;
    }
  };

  const handleQuestComplete = (pointsEarned: number) => {
    user.points = (user.points || 0) + pointsEarned;
    const newMiles = (userMiles || 0) + 10;
    setUserMiles(newMiles);
    user.miles = newMiles;
  };
  
  const handleUpdateMiles = (amount: number) => {
    const newMiles = userMiles + amount;
    setUserMiles(newMiles);
    user.miles = newMiles;
  };

  const menuItems = [
    { id: 'home', label: 'Dashboard', icon: <Home size={20} /> },
    { id: 'planner', label: 'Buat Trip', icon: <PlusCircle size={20} /> },
    { id: 'ai_tools', label: 'AI Toolbox', icon: <Wrench size={20} /> },
    { id: 'play_zone', label: 'PlayZone (Games)', icon: <Gamepad2 size={20} /> }, // New
    { id: 'route_map', label: 'Peta Rute', icon: <Map size={20} /> },
    { id: 'library', label: 'Library', icon: <BookOpen size={20} /> },
    { id: 'trip_ready', label: 'TripReady AI', icon: <CheckSquare size={20} /> },
    { id: 'monetization', label: 'Cuan & Rewards', icon: <Gift size={20} /> }, 
    { id: 'community', label: 'Social Feed', icon: <Users size={20} /> },
    { id: 'history', label: 'Riwayat', icon: <Calendar size={20} /> },
  ];

  const verticalFilters = [
    { id: 'trending', label: 'Trending', icon: <Flame size={18} />, color: 'text-orange-500' },
    { id: 'hidden', label: 'Hidden Gem', icon: <Gem size={18} />, color: 'text-purple-500' },
    { id: 'favorite', label: 'Terfavorit', icon: <CheckSquare size={18} />, color: 'text-pink-500' },
    { id: 'budget', label: 'Hemat', icon: <DollarSign size={18} />, color: 'text-green-500' },
    { id: 'value', label: 'Best Value', icon: <TrendingUp size={18} />, color: 'text-blue-500' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-dark-bg flex font-sans transition-colors duration-300 overflow-hidden">
      
      {/* Live Activity Popup */}
      <LiveActivityPopup />

      {/* Sidebar (Desktop) */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-white dark:bg-dark-card border-r border-slate-200 dark:border-dark-border transform transition-transform duration-300 ease-in-out md:translate-x-0 ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} overflow-y-auto flex flex-col`}>
        <div className="flex-1">
          {/* Brand */}
          <div className="h-20 flex items-center px-6 border-b border-slate-100 dark:border-dark-border sticky top-0 bg-white dark:bg-dark-card z-10">
            <div className="bg-emerald-600 p-1.5 rounded-lg text-white mr-2">
              <Compass size={20} />
            </div>
            <span className="text-lg font-extrabold text-slate-800 dark:text-white tracking-tight">NusantaraGo</span>
            <button className="md:hidden ml-auto text-slate-500 dark:text-slate-400" onClick={() => setMobileMenuOpen(false)}>
              <X size={20} />
            </button>
          </div>

          {/* Navigation */}
          <nav className="px-4 py-6 space-y-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                   setActiveView(item.id as DashboardView);
                   setMobileMenuOpen(false);
                   if (item.id === 'planner') onResetTrip();
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm ${
                  activeView === item.id 
                    ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 shadow-sm font-bold' 
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </nav>
        </div>

        {/* User Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-dark-border bg-white dark:bg-dark-card sticky bottom-0">
           <div 
              className="flex items-center gap-3 mb-4 px-2 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 p-2 rounded-lg transition-colors"
              onClick={() => setActiveView('profile')}
           >
             <div className="w-10 h-10 rounded-full bg-emerald-100 dark:bg-emerald-900 flex items-center justify-center text-emerald-700 dark:text-emerald-400 font-bold overflow-hidden border-2 border-white dark:border-slate-700 shadow-sm">
                 <img src={user.avatar} alt="Avatar" className="w-full h-full object-cover" />
             </div>
             <div className="flex-1 min-w-0">
               <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{user.name}</p>
               <div className="flex items-center gap-1 text-xs text-amber-500 font-bold">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span> Sultan Tier
               </div>
             </div>
           </div>
           <button 
             onClick={onLogout}
             className="w-full flex items-center gap-2 px-4 py-2 text-slate-400 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-600 dark:hover:text-red-400 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
           >
             <LogOut size={14} /> Logout
           </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 flex flex-col min-h-screen relative overflow-hidden">
        
        {/* Mobile Header */}
        <header className="h-16 bg-white dark:bg-dark-card border-b border-slate-200 dark:border-dark-border flex items-center justify-between px-4 md:hidden sticky top-0 z-30">
          <button onClick={() => setMobileMenuOpen(true)}>
            <Menu size={24} className="text-slate-600 dark:text-slate-300" />
          </button>
          <span className="font-bold text-slate-800 dark:text-white">NusantaraGo</span>
          <button 
            onClick={toggleDarkMode}
            className="p-2 text-slate-600 dark:text-yellow-400 transition-colors"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </header>

        {/* Content Area */}
        <div className="flex-1 p-4 md:p-8 overflow-y-auto relative z-10">
          
          {/* Top Bar Desktop */}
          <div className="hidden md:flex justify-between items-center mb-8 bg-white/80 dark:bg-dark-card/80 backdrop-blur-md p-4 rounded-2xl shadow-sm border border-slate-100 dark:border-dark-border sticky top-0 z-20">
             <div className="flex items-center gap-4">
                 <h1 className="text-xl font-bold text-slate-800 dark:text-white capitalize flex items-center gap-2">
                    {activeView === 'home' ? 'Dashboard' : activeView.replace('_', ' ')}
                </h1>
             </div>

            <div className="flex items-center gap-6">
               <button 
                  onClick={toggleDarkMode}
                  className="p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-yellow-400 transition-colors hover:bg-slate-200 dark:hover:bg-slate-700"
               >
                  {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
               </button>

               {/* New Premium Stats Card */}
               <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-900 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800">
                   <div className="flex items-center gap-2">
                       <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center text-emerald-600">
                          <Wallet size={16} />
                       </div>
                       <div>
                           <div className="text-[10px] text-slate-400 font-bold uppercase">Saldo</div>
                           <div className="text-sm font-bold text-slate-800 dark:text-white">Rp {walletAmount.toLocaleString()}</div>
                       </div>
                   </div>
                   <div className="h-8 w-[1px] bg-slate-200 dark:bg-slate-700"></div>
                   <div className="flex items-center gap-2">
                       <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-900/50 flex items-center justify-center text-amber-600">
                          <Gem size={16} />
                       </div>
                       <div>
                           <div className="text-[10px] text-slate-400 font-bold uppercase">Miles</div>
                           <div className="text-sm font-bold text-slate-800 dark:text-white">{userMiles.toLocaleString()} mi</div>
                       </div>
                   </div>
               </div>
               
               <button className="p-2 text-slate-400 hover:text-emerald-600 transition-colors relative">
                <Bell size={20} />
                <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-dark-card"></span>
              </button>
            </div>
          </div>

          {/* Vertical Filters (Right Side) */}
          {activeView === 'home' && (
             <div className={`fixed right-6 top-32 z-20 flex flex-col gap-2 transition-transform duration-300 ${showRightFilters ? 'translate-x-0' : 'translate-x-full'}`}>
                <div className="bg-white dark:bg-dark-card p-2 rounded-2xl shadow-xl border border-slate-200 dark:border-dark-border flex flex-col gap-1 w-14 hover:w-48 transition-all duration-300 group overflow-hidden">
                    <button onClick={() => setShowRightFilters(!showRightFilters)} className="self-center p-2 text-slate-400">
                        <Filter size={20} />
                    </button>
                    <div className="h-[1px] bg-slate-100 dark:bg-slate-800 my-1 mx-2"></div>
                    {verticalFilters.map(filter => (
                        <button
                          key={filter.id}
                          onClick={() => setActiveFilter(activeFilter === filter.id ? null : filter.id)}
                          className={`flex items-center gap-3 p-2 rounded-xl transition-colors whitespace-nowrap ${
                             activeFilter === filter.id 
                             ? 'bg-slate-100 dark:bg-slate-800' 
                             : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                          }`}
                        >
                            <div className={`${filter.color}`}>{filter.icon}</div>
                            <span className="text-sm font-bold text-slate-700 dark:text-slate-200 opacity-0 group-hover:opacity-100 transition-opacity duration-200 delay-100">{filter.label}</span>
                        </button>
                    ))}
                </div>
             </div>
          )}

          {/* Views */}
          {activeView === 'home' && (
             <div className="space-y-8 animate-in fade-in duration-500 max-w-[calc(100%-80px)]">
               {/* Neon Map Header */}
               <div className="relative rounded-3xl p-8 md:p-12 overflow-hidden shadow-2xl bg-black min-h-[300px] flex items-center">
                 {/* Background Map Visual */}
                 <div className="absolute inset-0 z-0">
                     <img 
                        src="https://images.unsplash.com/photo-1555982845-8c7694318d10?q=80&w=2000&auto=format&fit=crop" 
                        className="w-full h-full object-cover opacity-40 mix-blend-luminosity" 
                        alt="Map"
                     />
                     <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent"></div>
                     <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black to-transparent"></div>
                 </div>

                 <div className="relative z-10 max-w-2xl">
                    <div className="flex items-center gap-2 mb-4">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span className="text-emerald-400 font-bold uppercase tracking-widest text-xs">Ready to explore?</span>
                    </div>
                    <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-4 leading-tight">
                        Selamat Datang, <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">{user.name.split(' ')[0]}</span>!
                    </h2>
                    <p className="text-slate-300 text-lg mb-8 max-w-md">Dunia luas banget, sayang kalau cuma dilihat dari layar HP. Yuk, realisasikan wacanamu hari ini.</p>
                    
                    <div className="flex flex-wrap gap-4">
                        <button 
                          onClick={() => setActiveView('planner')}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-3.5 rounded-xl font-bold shadow-lg shadow-emerald-900/40 transition-all hover:scale-105 flex items-center gap-2"
                        >
                          <PlusCircle size={20} /> Buat Trip Baru
                        </button>
                        <button 
                          onClick={() => setIsPanduOpen(true)}
                          className="bg-white/10 hover:bg-white/20 border border-white/20 text-white px-8 py-3.5 rounded-xl font-bold backdrop-blur-md transition-all flex items-center gap-2"
                        >
                          <Bot size={20} /> Tanya Pandu AI
                        </button>
                    </div>
                 </div>
               </div>

               {/* Inspirational Content - Horizontal Scroll Grid */}
               <div>
                 <div className="flex justify-between items-end mb-6">
                    <div>
                        <h3 className="font-bold text-slate-800 dark:text-white text-2xl">Inspirasi Minggu Ini</h3>
                        <p className="text-slate-500 dark:text-slate-400">Destinasi pilihan kurasi AI spesial buat kamu.</p>
                    </div>
                    <button className="text-emerald-600 dark:text-emerald-400 font-bold text-sm hover:underline">Lihat Semua</button>
                 </div>
                 
                 <div className="flex gap-6 overflow-x-auto pb-8 scrollbar-hide snap-x snap-mandatory">
                   {['Raja Ampat', 'Danau Toba', 'Likupang', 'Mandalika', 'Labuan Bajo'].map((place, i) => (
                     <div key={place} className="min-w-[280px] md:min-w-[320px] h-[400px] snap-center group relative rounded-3xl overflow-hidden cursor-pointer shadow-lg border border-slate-100 dark:border-dark-border" onClick={() => setActiveView('planner')}>
                       <img 
                        src={`https://source.unsplash.com/400x600/?${place.replace(' ', '')},indonesia`} 
                        alt={place}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                        onError={(e) => (e.currentTarget.src = 'https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?q=80&w=2070&auto=format&fit=crop')}
                       />
                       <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent flex flex-col justify-end p-6">
                         <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                           <h4 className="text-2xl font-bold text-white mb-1">{place}</h4>
                           <div className="flex items-center gap-1 text-xs text-yellow-400 mb-2">
                               <Gem size={12} /> Super Priority Destination
                           </div>
                           <p className="text-sm text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity delay-100 line-clamp-2">
                               Nikmati keindahan alam Indonesia yang memukau. Klik untuk buat itinerary ke sini.
                           </p>
                         </div>
                       </div>
                       
                       {/* Parallax Border Effect */}
                       <div className="absolute inset-0 border-4 border-emerald-500/0 group-hover:border-emerald-500/50 rounded-3xl transition-all duration-500 pointer-events-none"></div>
                     </div>
                   ))}
                 </div>
               </div>
             </div>
          )}

          {activeView === 'planner' && <TripPlanner onGenerate={handleGenerate} isLoading={isLoading} />}
          {activeView === 'trip_ready' && <TripReady />}
          {activeView === 'ai_tools' && <AIToolsHub />} 
          {activeView === 'monetization' && <MonetizationHub />}
          {activeView === 'community' && <Community />}
          {activeView === 'route_map' && <VisualRouteMap />}
          {activeView === 'library' && <TravelerLibrary />}
          {activeView === 'play_zone' && <PlayZoneHub userMiles={userMiles} onUpdateMiles={handleUpdateMiles} />}
          
          {activeView === 'trip_detail' && displayPlan && (
            <div className="space-y-6">
                {/* Nusantara Lingo Widget (Main Content Area) */}
                <div className="mb-2">
                     <NusantaraLingo destination={displayPlan.trip_summary.title} />
                </div>
                
                <ItineraryView 
                    plan={displayPlan} 
                    onReset={handleBackToPlanner} 
                    userBudget={walletAmount}
                    onOptimize={handleOptimizeBudget}
                    onQuestComplete={handleQuestComplete}
                />
            </div>
          )}

          {activeView === 'profile' && <UserProfile user={user} />}
          
          {/* Empty States */}
           {activeView === 'history' && (
             <div className="flex flex-col items-center justify-center h-64 text-slate-400 dark:text-slate-600">
               <Calendar size={48} className="mb-4 opacity-50" />
               <p>Belum ada riwayat perjalanan.</p>
               <button onClick={() => setActiveView('planner')} className="mt-4 text-emerald-600 dark:text-emerald-400 font-bold hover:underline">Mulai Petualangan</button>
             </div>
           )}

        </div>
      </main>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-4 z-50">
        
        {/* Pandu AI FAB */}
        <button
          onClick={() => setIsPanduOpen(true)}
          className="p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-110 border-4 border-white dark:border-slate-800 bg-slate-900 text-emerald-400 hover:bg-black group relative"
        >
          <Bot size={28} className="group-hover:animate-bounce" />
          <span className="absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-slate-900 text-white text-xs font-bold px-3 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            Pandu AI Agent
          </span>
          <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full animate-ping"></span>
        </button>

      </div>

      {/* Pandu Command Center Modal */}
      {isPanduOpen && (
        <PanduCommandCenter 
          onClose={() => setIsPanduOpen(false)} 
          userName={user.name} 
        />
      )}

    </div>
  );
};

export default Dashboard;
