
import React, { useState } from 'react';
import { Map, Plane, Car, Train, ArrowRight, MapPin, Info } from 'lucide-react';

const VisualRouteMap: React.FC = () => {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [isSimulating, setIsSimulating] = useState(false);

  const handleSimulate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!from || !to) return;
    setIsSimulating(true);
    // Simulation state handled by visuals
  };

  return (
    <div className="max-w-6xl mx-auto pb-20 animate-in fade-in slide-in-from-bottom-4">
      <div className="bg-slate-900 rounded-3xl overflow-hidden shadow-2xl relative min-h-[600px] border border-slate-800">
        
        {/* Map Background (Placeholder for interactive map) */}
        <div className="absolute inset-0 bg-[url('https://upload.wikimedia.org/wikipedia/commons/thumb/b/bb/Indonesia_provinces_blank.png/1200px-Indonesia_provinces_blank.png')] bg-cover bg-center opacity-20 filter invert"></div>
        
        {/* Overlay UI */}
        <div className="relative z-10 p-8">
          <h2 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
            <Map className="text-emerald-500" /> Visual Route Planner
          </h2>
          <p className="text-slate-400 mb-8 max-w-xl">Simulasikan perjalananmu antar pulau. Lihat rute, estimasi waktu, dan titik-titik menarik yang akan kamu lewati.</p>

          <form onSubmit={handleSimulate} className="flex flex-col md:flex-row gap-4 bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/10 max-w-3xl">
            <div className="flex-1 space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase ml-1">Dari Mana</label>
              <input 
                type="text" 
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                placeholder="Jakarta"
                className="w-full bg-slate-800 border border-slate-700 text-white px-4 py-3 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
            <div className="flex items-center justify-center pt-6">
              <ArrowRight className="text-slate-500" />
            </div>
            <div className="flex-1 space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase ml-1">Ke Mana</label>
              <input 
                type="text" 
                value={to}
                onChange={(e) => setTo(e.target.value)}
                placeholder="Labuan Bajo"
                className="w-full bg-slate-800 border border-slate-700 text-white px-4 py-3 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
            <div className="flex items-end">
              <button 
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-3.5 rounded-xl font-bold shadow-lg shadow-emerald-900/20 transition-all"
              >
                Simulasikan Rute
              </button>
            </div>
          </form>
        </div>

        {/* Simulation Visualization */}
        {isSimulating && (
          <div className="absolute inset-0 z-0 pointer-events-none">
            {/* Animated Path (Conceptual CSS) */}
            <svg className="absolute inset-0 w-full h-full">
              <path 
                d="M 200 400 Q 400 300 800 450" 
                fill="none" 
                stroke="#10B981" 
                strokeWidth="3" 
                strokeDasharray="10,10"
                className="animate-pulse"
              />
              <circle cx="200" cy="400" r="8" fill="white" className="animate-ping" />
              <circle cx="800" cy="450" r="8" fill="#F59E0B" />
            </svg>

            {/* Transport Icon Moving */}
            <div className="absolute top-[350px] left-[300px] bg-white text-slate-900 p-2 rounded-full shadow-xl animate-bounce">
              <Plane size={24} className="rotate-45" />
            </div>

            {/* Popups */}
            <div className="absolute top-[300px] left-[500px] bg-white/90 backdrop-blur p-3 rounded-xl shadow-lg border border-white max-w-[150px] animate-in zoom-in duration-500 delay-700">
              <img src="https://source.unsplash.com/200x150/?surabaya" className="w-full h-20 object-cover rounded-lg mb-2" />
              <div className="text-xs font-bold text-slate-800">Lewat Surabaya?</div>
              <div className="text-[10px] text-slate-500">Coba Rawon Setan!</div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default VisualRouteMap;
